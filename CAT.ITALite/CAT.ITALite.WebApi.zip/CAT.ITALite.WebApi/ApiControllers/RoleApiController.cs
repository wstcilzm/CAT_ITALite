﻿using System.Configuration;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using CAT.ITALite.Common;
using CAT.ITALite.Entity;
using System.Collections.Generic;


namespace CAT.ITALite.WebApi.ApiControllers
{
    [RoutePrefix("api/role")]
    public class RoleApiController : ApiControllerBase
    {
        [HttpGet]
        [Route("list")]
        public async Task<IHttpActionResult> GetRolesAsync()
        {
            var operation = new TableDal(ConfigurationManager.AppSettings["storageConnection"], TableNames.AADAdminRoles);
            var result = operation.RetrieveAdminRoles();
            return CreateSuccessResult(result);
        }

        [HttpGet]
        [Route("{roleId}/users")]
        public async Task<IHttpActionResult> GetUsersAsync(string roleId)
        {
            var operation = new TableDal(ConfigurationManager.AppSettings["storageConnection"], TableNames.UserAdminRoleAssignments);
            var result = (IEnumerable<UserAdminRoleAssignmentEntity>)(operation.RetrieveUsersByRoleId(roleId));
            return CreateSuccessResult(result);
        }
        
        [HttpGet]
        [Route("rbac/list")]
        public async Task<IHttpActionResult> GetRbacRolesAsync()
        {
            var operation = new TableDal(ConfigurationManager.AppSettings["storageConnection"], TableNames.RBACRoles);
            var result = operation.RetrieveRbacRoles();
            return CreateSuccessResult(result);
        }

        [HttpGet]
        [Route("rbac/{roleId}/users")]
        public async Task<IHttpActionResult> GetRbacRolesUsersAsync(string roleId)
        {
            var operation = new TableDal(ConfigurationManager.AppSettings["storageConnection"], TableNames.UserRBACRoleAssignments);
            var result = operation.RetrieveUsersByRbacRoleId(roleId);
            return CreateSuccessResult(result);
        }

        [HttpGet]
        [Route("rbac/{roleIds}/groups")]
        public async Task<IHttpActionResult> GetRMGroupsAsync(string roleIds)
        {
            List<RmAccessGroupView> list = new List<RmAccessGroupView>();
            string[] array= roleIds.Split(';');
            foreach (string roles in array)
            {
                if (!string.IsNullOrEmpty(roleIds))
                {
                    string[] role = roleIds.Split(',');
                    string roleId = role[0];
                    string roleName = role[1];
                    var operation = new TableDal(ConfigurationManager.AppSettings["storageConnection"], TableNames.RGRBACRoleAssignments);
                    var RGresult = operation.RetrieveRMGroupsByRbacRoleId(roleId);
                    foreach (RGRBACRoleAssignmentEntity RG_entity in RGresult)
                    {
                        string rmGroupName = RG_entity.PartitionKey.Substring(RG_entity.PartitionKey.LastIndexOf("&") + 1);
                        operation = new TableDal(ConfigurationManager.AppSettings["storageConnection"], TableNames.RMResourceGroups);
                        var RMresult = operation.RetrieveRMGroup(rmGroupName);
                        foreach (RMResourceGroupEntiry RmG_entity in RMresult)
                        {
                            list.Add(new RmAccessGroupView(RmG_entity, roleName));
                        }
                    }
                }
            }
            return CreateSuccessResult(list);
        }

    }
}